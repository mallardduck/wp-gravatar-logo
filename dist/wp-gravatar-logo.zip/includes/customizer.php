<?php
/**
 * Customizer functionality
 *
 * @package   WP Gravatar Logo
 * @author    Rich Tabor of ThemeBeans <hello@themebeans.com>
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Register Customizer Settings.
 *
 * @param WP_Customize_Manager $wp_customize the Customizer object.
 */
function wp_gravatar_logo_customize_register( $wp_customize ) {

	/**
	 * Add the site logo max-width option to the Site Identity section.
	 */
	$wp_customize->add_setting( 'wp_gravatar_logo__width', array(
		'default'               => '50',
		'transport'             => 'postMessage',
		'sanitize_callback'     => 'absint',
	) );

	$wp_customize->add_control( new WP_Gravatar_Logo_Range_Control( $wp_customize, 'wp_gravatar_logo__width', array(
		'default'               => '50',
		'type'                  => 'wp-gravatar-logo-range',
		'label'                 => esc_html__( 'Avatar Width', 'wp-gravatar-logo' ),
		'description'           => 'px',
		'section'               => 'title_tagline',
		'priority'              => 9,
		'input_attrs'           => array(
			'min'               => 0,
			'max'               => 200,
			'step'              => 2,
		),
	) ) );

}
add_action( 'customize_register', 'wp_gravatar_logo_customize_register', 11 );
