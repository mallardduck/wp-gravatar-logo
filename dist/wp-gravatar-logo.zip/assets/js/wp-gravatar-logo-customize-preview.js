/**
 * File customize-preview.js.
 *
 * Instantly live-update customizer settings in the preview for improved user experience.
 */

(function( $ ) {

	// Gravatar size.
	wp.customize( 'wp_gravatar_logo__width', function( value ) {
		value.bind( function( to ) {
			$( '.custom-logo-link--avatar img' ).css( 'width', to );
		});
	});



	wp.customize( 'blogname', function( setting ) {
		setting.bind( function( value ) {
			setting.notifications.add( code, new wp.customize.Notification(
				code,
				{
					type: 'warning',
					message: 'This theme prefers title with max 20 chars.'
				}
			) );
		} );
	} );


} )( jQuery );
